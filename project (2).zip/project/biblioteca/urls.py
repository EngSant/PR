from django.conf.urls import url
from . import views

app_name = 'biblioteca'
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^pesquisa/$', views.resultado, name='resultado'),
    url(r'^genero/(?P<genero_type>.+)/$', views.genero, name='genero'),
    url(r'^loginpage/', views.loginpage, name='loginpage'),
    url(r'^login/$', views.loginview, name='loginview'),
    url(r'^registerpage/$', views.registerpage, name='registerpage'),
    url(r'^inscricao/$', views.registerview, name='registerview'),
    url(r'^(?P<livro_id>[0-9]+)/detalhe/$', views.detalhe, name='detalhe'),
    url(r'^(?P<livro_id>[0-9]+)/alugar/$', views.alugar, name='alugar'),
    url(r'^sair/$', views.logoutview, name='logoutview'),
    url(r'^perfil/$', views.perfil, name='perfil'),
    url(r'^editarprinome/$', views.editarprinome, name='editarprinome'),
    url(r'^editarultnome/$', views.editarultnome, name='editarultnome'),
    url(r'^editarsaldo/$', views.editarsaldo, name='editarsaldo'),
    url(r'^mybooks/$', views.basket, name='basket'),
    url(r'^simple_upload/$', views.simple_upload, name='simple_upload'),
]