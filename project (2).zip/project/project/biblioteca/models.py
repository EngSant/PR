from django.db import models
from django.contrib.auth.models import User
from django.utils.encoding import python_2_unicode_compatible


class Livro(models.Model):
    titulo = models.CharField(max_length=100)
    autor = models.CharField(max_length=100)
    editora = models.CharField(max_length=100)
    genero = models.CharField(max_length=20)
    lingua = models.CharField(max_length=20)
    pontuacao = models.IntegerField(default=0)
    preco = models.IntegerField(default=0)

    def __str__(self):
        return self.titulo


class Utilizador(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    telemovel = models.CharField(max_length=9)
    saldo = models.IntegerField(default=0)

    def __str__(self):
        return self.user.username


class Tabela(models.Model):
    livro = models.ForeignKey(Livro, on_delete=models.CASCADE)
    utilizador = models.ForeignKey(Utilizador, on_delete=models.CASCADE)
    alugado = models.BooleanField()
    data_alug = models.DateTimeField('data de aluguer')

    def __str__(self):
        return "Livro: "+ self.livro.titulo + ", " + "Alugado por: " + self.utilizador.user.username


