from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.urls import reverse
from biblioteca.models import Livro, Utilizador, Tabela
from django.template import loader
from django.contrib.auth import authenticate, login, logout
from django.utils import timezone
from django.contrib.auth.models import User
import datetime

def titulos():
    tab = {}
    i = 1
    livros = Livro.objects.all()
    for t in livros:
        tab[i] = t.titulo
        i += 1
    return tab

def search(query):
    a = {}
    tab = Livro.objects.all()
    for l in tab:
        if query.lower() in l.titulo.lower():
            a[l] = l
    for p in tab:
        if query.lower() in p.autor.lower():
            a[p] = p
    return a


def index(request):
    select_genero = Livro.objects.order_by('genero')
    context = {'select_genero': select_genero,}
    return render(request, 'biblioteca/index.html', context)


def genero(request, genero_type):
    try:
        livros = Livro.objects.filter(genero=genero_type)
    except Livro.DoesNotExist:
        raise Http404("Não existem livros deste género")
    return render(request, 'biblioteca/genero.html', {'livros': livros, 'genero': genero_type},)


def resultado(request):
    try:
        query = request.POST['pesquisa']
        result = search(query)
    except ValueError:
        raise Http404("Procura inválida")
    return render(request, 'biblioteca/resultado.html', {'livros': result})


def loginpage(request):
    return render(request, 'biblioteca/login.html')


def loginview(request):
    try:
        user1 = request.POST['puser']
        pass1 = request.POST['ppass']

        utilizador = authenticate(username=user1, password=pass1)

        if utilizador is not None:
            login(request, utilizador)
            return HttpResponseRedirect(reverse('biblioteca:index'), {'utilizador': utilizador},)
        else:
            return render(request,'biblioteca/login.html', {'error_message': "Login inválido"})
    except Utilizador.DoesNotExist:
        raise Http404("Utilizador inválido")


def registerpage(request):
    return render(request, 'biblioteca/register.html')


def registerview(request):

    uname = request.POST['batatas']
    pw = request.POST['password']
    telemovel = request.POST['telemovel']
    email = request.POST['email']
    pw2 = request.POST['repeat_password']

    if pw != pw2:
        return render(request, 'biblioteca/register.html', {'error_message': "Indicou duas password's diferentes"})

    for a in User.objects.all():
        if a.username == uname:
            return render(request, 'biblioteca/register.html', {'error_message': "Username já existe"})

    us = User.objects.create_user(uname, email, pw)
    us.save()

    u = Utilizador(user=us, telemovel=telemovel)
    u.save()

    return HttpResponseRedirect(reverse('biblioteca:index'),)


def logoutview(request):
    logout(request)
    return HttpResponseRedirect(reverse('biblioteca:index'),)


def perfil(request):
    ut_id = request.user
    utilizador = Utilizador.objects.get(user=ut_id)
    return render(request, 'biblioteca/perfil.html', {'utilizador': utilizador},)


def editarprinome(request):
    try:
        prime_nome = request.POST['prime_nome']
        ut_id = request.user
        utilizador = Utilizador.objects.get(user_id=ut_id)
        utilizador.user.first_name = prime_nome
        utilizador.user.save()
        return HttpResponseRedirect(reverse('biblioteca:perfil'), )
    except Utilizador.DoesNotExist:
        return Http404("Utilizador inválido")


def editarultnome(request):
    try:
        ult_nome = request.POST['ult_nome']
        ut_id = request.user
        utilizador = Utilizador.objects.get(user_id=ut_id)
        utilizador.user.last_name = ult_nome
        utilizador.user.save()
        return HttpResponseRedirect(reverse('biblioteca:perfil'), )
    except Utilizador.DoesNotExist:
        return Http404("Utilizador inválido")


def editarsaldo(request):
    try:
        wallet = request.POST['wallet']
        ut_id = request.user
        utilizador = Utilizador.objects.get(user_id=ut_id)
        sald = (int)(utilizador.saldo) + int(wallet)
        utilizador.saldo = sald
        utilizador.save()
        return HttpResponseRedirect(reverse('biblioteca:perfil'), )
    except Utilizador.DoesNotExist:
        return Http404("Utilizador inválido")


def detalhe(request, livro_id):

    livro = get_object_or_404(Livro, id=livro_id)
    tabela = False
    if request.user.is_authenticated:
        ut_id = request.user
        util = Utilizador.objects.get(user_id=ut_id)
        try:
            t = Tabela.objects.get(livro_id=livro_id, utilizador_id=util.id)
            if t is not None:
                tabela = True
                return render(request, 'biblioteca/detalhe.html', {'livro': livro, 'tabela': tabela})
        except Tabela.DoesNotExist:
            return render(request, 'biblioteca/detalhe.html', {'livro': livro, 'tabela': tabela})
    return render(request, 'biblioteca/detalhe.html', {'livro': livro, 'tabela': tabela})


def alugar(request, livro_id):
    livro = get_object_or_404(Livro, id=livro_id)
    if request.user.is_authenticated:
        ut_id = request.user
        util = Utilizador.objects.get(user_id=ut_id)
        price = livro.preco
        if int(price) > int(util.saldo):
            return render(request, 'biblioteca/detalhe.html',{'livro': livro, 'error_message': "Saldo insuficiente"})
        try:
            t = Tabela.objects.get(livro_id=livro_id, utilizador_id=util.id)
            if t is not None:
                if t.data_alug > timezone.now():
                    tabela = True
                    return render(request, 'biblioteca/detalhe.html', {'livro': livro, 'error_message': "JÁ ALUGADO", 'tabela': tabela})
                else:
                    t.data_alug = timezone.now()+datetime.timedelta(days=5)
                    t.save()
                    return HttpResponseRedirect(reverse('biblioteca:detalhe', args=(livro.id, t.data_alug,)))
            else:
                t = Tabela.objects.create(livro=livro, utilizador=util, alugado=True,
                                          data_alug=timezone.now() + datetime.timedelta(days=5))
                t.save()
                return HttpResponseRedirect(reverse('biblioteca:detalhe', args=livro.id,))
        except Tabela.DoesNotExist:
            t = Tabela.objects.create(livro=livro, utilizador=util, alugado=True,
                                      data_alug=timezone.now() + datetime.timedelta(days=5))
            t.save()
            wallet = int(util.saldo) - int(price)
            util.saldo = wallet
            util.save()
            return HttpResponseRedirect(reverse('biblioteca:detalhe', args=livro_id,), {'error_message': "Alugou o livro"})
    else:
        return render(request, 'biblioteca/detalhe.html', {'livro': livro, 'error_message': "Tem que fazer login"})




